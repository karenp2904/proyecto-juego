import axios from "axios";

export interface ITipo {
    _id: string;
    descripcion: string;
    createdAt: string;
    updatedAt: string;
}


export class TiposService {

    static obtenerTipos(): Promise<ITipo[]> {
        return new Promise((res) => {
            axios.get("http://192.168.10.13:3000/api/tipo")
            .then(_res => res(_res.data.data))
            .catch(() => {res([])})
        })
    }

    static obtenerSubTipos(id: string): Promise<ITipo[]> {
        return new Promise((res) => {
            axios.get(`http://192.168.10.13:3000/api/subtipo/${id}`)
            .then(_res => res(_res.data.data))
            .catch(() => {res([])})
        })
    }

}