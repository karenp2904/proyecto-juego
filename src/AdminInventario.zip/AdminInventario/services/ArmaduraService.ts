import axios from "axios";
import { ArmaduraData } from "../app/pages/admin/crearArmadura/CrearArmaduraPage";

export class ArmaduraService {
  static guardarArma(armadura: ArmaduraData, image: File): Promise<void> {
    const formData = new FormData();
    formData.append('tipo', armadura.tipo);
    formData.append('subtipo', armadura.subtipo);
    // formData.append('stock', arma.stock.toString());
    formData.append('descripcion', armadura.descripcion);

    // Agregar estadisticas
    formData.append('estadisticas', JSON.stringify(armadura.estadisticas));

    // Agregar armas (nombre, efectos, porcentajeCaida)
    formData.append('armadura', JSON.stringify(armadura.armadura));

    // Adjuntar la imagen
    formData.append("image", image);

    return new Promise((res, rej) => {
      axios.post("http://192.168.10.13:3000/api/arma", formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then(() => res())
      .catch(err => rej(err));
    });
  }
}
